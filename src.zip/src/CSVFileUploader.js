import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';

import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from "react-router-dom";

 
const CSVFileUploader = () => {
  const [message, setMessage] = useState(null);
  const [files, setFiles] = useState([]);
  const [fileNames, setFileNames] = useState([]);
  const [batchID, setBatchID] = useState(parseInt(localStorage.getItem('lastBatchID'), 10) || 1);
  const [uploadHistory, setUploadHistory] = useState(JSON.parse(localStorage.getItem('uploadHistory')) || []);
 
  useEffect(() => {
    localStorage.setItem('uploadHistory', JSON.stringify(uploadHistory));
    localStorage.setItem('lastBatchID', batchID);
  }, [uploadHistory, batchID]);
 
  useEffect(() => {
    let timer;
    if (message) {
      timer = setTimeout(() => {
        setMessage(null);
      }, 5000); // 5 seconds duration for the message
    }
 
    return () => clearTimeout(timer);
  }, [message]);
 
  const handleFileUpload = (event) => {
    const uploadedFiles = event.target.files;
    const fileNamesArray = Array.from(uploadedFiles).map((file) => file.name);
    setFileNames(fileNamesArray);
    setFiles(uploadedFiles);
  };
 
  const startValidation = () => {
    const currentBatchID = batchID;
    setBatchID(currentBatchID + 1);
 
    fileNames.forEach((fileName, index) => {
      const file = files[index];
      const fileReader = new FileReader();
 
      fileReader.onload = (e) => {
        const csvData = e.target.result;
 
        Papa.parse(csvData, {
          header: true,
          skipEmptyLines: true,
          complete: (parsedData) => {
 
            const requiredColumns = ['EntityName', 'Description', 'FeatureName', 'FeatureValue', 'FeatureDataType'];
            const dataColumns = Object.keys(parsedData.data[0]); // Assuming the columns are in the first row
 
            const missingColumns = requiredColumns.filter((column) => !dataColumns.includes(column));
 
            if (missingColumns.length > 0) {
              setMessage(
                (prevMessage) =>
                  (prevMessage ? `${prevMessage}\n` : '') +
                  `Error: ${fileName} is missing required columns: ${missingColumns.join(', ')}.`
              );
              return;
            }
 
            const rowsWithEmptyValues = parsedData.data.filter((row) => {
              return Object.values(row).some((value) => !value);
            });
 
            const status =
              rowsWithEmptyValues.length > 0 || parsedData.data.length === 0 || missingColumns.length > 0
                ? 'Not Uploaded'
                : 'Completed';
 
            if (rowsWithEmptyValues.length > 0) {
              setMessage(
                (prevMessage) =>
                  (prevMessage ? `${prevMessage}\n` : '') + `Error: ${fileName} contains rows with empty values.`
              );
              return;
            }
 
            if (parsedData.data.length === 0) {
              setMessage((prevMessage) => (prevMessage ? `${prevMessage}\n` : '') + `Error: ${fileName} is empty.`);
              return;
            }
 
            setMessage((prevMessage) => (prevMessage ? `${prevMessage}\n` : '') + `Upload successful: ${fileName} has data.`);
            const uploadTime = new Date().toLocaleString();
            const uploadDetails = {
              batchID: currentBatchID,
              fileName,
              uploadTime,
              //   status,
              data: parsedData.data,
            };
            setUploadHistory((prevHistory) => [...prevHistory, uploadDetails]);
          },
        });
      };
 
      fileReader.readAsText(file);
    });
 
    setFileNames([]);
    setFiles([]);
  };
 
  return (
    <>
 
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="/">Feature Marketplace</a>
 
 
          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            {/* <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"></input>
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form> */}
            <div className='col-md-4 offset-1'>
              <div className='input-group'>
                <button type='button' className='btn btn-info'>Search</button>
                <input type='text' className='form-control'></input>
              </div>
            </div>
            <ul class="navbar-nav offset-1">
              <li class="nav-item">
                <Link class="nav-link active"
                  aria-current="page" to="searchuser">Custom Search</Link>
              </li>
              <li class="nav-item">
                <Link class="nav-link active"
                  aria-current="page" to="newfeature">Add Feature</Link>
              </li>
              <li class="nav-item">
                <Link class="nav-link active"
                  aria-current="page" to="featurehome">Upload Feature</Link>
              </li>
              <li class="nav-item">
                <Link class="nav-link active"
                  aria-current="page" to="featurehome">Favourites</Link>
              </li>
              <li class="nav-item">
                <Link class="nav-link active"
                  aria-current="page" to="featurehome">My Features</Link>
              </li>
            </ul>
 
          </div>
        </div>
      </nav>
 
      <br />
 
 
 
      <div class="main" className="container">
 
        <div className="upload-section">
 
          <div className="grids">
            <h1>Upload your CSV files
              <img  alt="My Image" style={{ marginLeft: '241px',marginBottom:'13px',border: '1px solid black', Align: 'right', width:"40%",height:"35%" }}/>
            </h1>
           
            <div className="grid-group">
              <input type="file" onChange={handleFileUpload} accept=".csv" />
            </div>
          </div>
 
          {fileNames.length > 0 && (
            <div className="file-selected">
              <h3>SELECTED FILES:</h3>
              <ul>
                {fileNames.map((fileName, index) => (
                  <li key={index}>{fileName}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
        <br />
 
        <button className="upload-button" onClick={startValidation}>
          Upload Batch
        </button>
        {message && (
          <p className={`message ${message.includes('Upload successful') ? 'success' : 'error'}`}>
            {message.includes('Error') ? <span style={{ color: 'red' }}>{message}</span> : message}
          </p>
        )}
      </div>
 
 
    </>
  );
};
 
export default CSVFileUploader;