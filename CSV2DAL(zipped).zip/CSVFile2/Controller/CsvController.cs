﻿
using CSVFileDAL.Model;
using CSVFileDAL.Models;
using CSVFileUpload.Services;
using CsvHelper.Configuration;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using Newtonsoft;
using Newtonsoft.Json;
using CSVFileUpload.DTO;
using Microsoft.AspNetCore.SignalR;
using CSVFileUpload.Hubs;

[ApiController]
[Route("[controller]")]
public class CSVController : ControllerBase
{
    private readonly ICSVService _csvService;
    private readonly IHubContext<ProgressHub> _hubContext;

    public CSVController(ICSVService csvService, IHubContext<ProgressHub> hubContext)
    {
        _csvService = csvService;
        _hubContext = hubContext;
    }



    [HttpPost("upload")]
    public async Task<IActionResult> GetEmployeeCSV([FromForm] IFormFileCollection files)
    {
        try
        {
            var entities = _csvService.ReadCSV<EntityTbl>(files[0].OpenReadStream());

            // Log CSV data
            foreach (var entity in entities)
            {
                Console.WriteLine($"EntityName: {entity.EntityName}, Description: {entity.Description}, ...");
            }

            var progress = new Progress<int>(value =>
            {
                _hubContext.Clients.All.SendAsync("ReceiveProgress", value.ToString());
            });

            await ProcessCSVWithProgress(entities, progress);

            // Call your API to send the CSV data and add entities to the database
            await CallApiAsync(entities, progress);

            // You might want to return a download link or other appropriate response
            return Ok(entities);
        }
        catch (Exception ex)
        {
            // Log the exception or handle it accordingly
            Console.WriteLine($"An error occurred while processing the file: {ex}");
            return StatusCode(500, "An error occurred while processing the file.");
        }
    }



    private async Task ProcessCSVWithProgress(IEnumerable<EntityTbl> entities, IProgress<int> progress)
    {
        int totalSteps = entities.Count();
        int currentStep = 0;

        foreach (var entity in entities)
        {
            // Simulate processing each entity by printing its name to the console
            Console.WriteLine($"Processing entity: {entity.EntityName}");

            // Simulate a slower progression by introducing a delay
            await Task.Delay(1000);

            // Send progress update to clients using SignalR
            progress.Report((currentStep + 1) * 100 / totalSteps);

            currentStep++;
        }
    }


    private async Task CallApiAsync(IEnumerable<EntityTbl> entities, IProgress<int> progress)
    {
        string baseApiUrl = "https://featuremarketplacewebapiforcrud.azurewebsites.net/api/Entity/AddEntity";

        using (var httpClient = new HttpClient())
        {
            httpClient.BaseAddress = new Uri(baseApiUrl);
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                int totalSteps = entities.Count();
                int currentStep = 0;

                foreach (var entity in entities)
                {
                    // Create an instance of EntityAddRequest for each entity
                    var entityAddRequest = new EntityAddRequest
                    {
                        EntityName = entity.EntityName,
                        Description = entity.Description,
                        // Set other properties based on your data
                    };

                    // Convert the EntityAddRequest to JSON
                    var jsonPayload = Newtonsoft.Json.JsonConvert.SerializeObject(entityAddRequest);
                    var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");

                    // Make the POST request for each entity
                    var response = await httpClient.PostAsync(baseApiUrl, content);

                    int currentProgress = (currentStep + 1) * 100 / totalSteps; // Move this line inside the loop

                    if (!response.IsSuccessStatusCode)
                    {
                        // Handle API call failure if needed
                        Console.WriteLine($"API call failed for entity {entity.EntityName}. Status code: {response.StatusCode}, Reason: {response.ReasonPhrase}");

                        var responseContent = await response.Content.ReadAsStringAsync();
                        Console.WriteLine($"Response content: {responseContent}");

                        try
                        {
                            var problemDetails = Newtonsoft.Json.JsonConvert.DeserializeObject<ProblemDetails>(responseContent);
                            if (problemDetails != null)
                            {
                                Console.WriteLine($"Problem Details: {problemDetails.Title}, {problemDetails.Detail}");
                                // Add more properties from the ProblemDetails class as needed
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error parsing problem details: {ex.Message}");
                        }

                        // Report progress and continue to the next entity
                        progress.Report(currentProgress);
                        continue;
                    }

                    // Report progress for the successful API call
                    progress.Report(currentProgress);

                    currentStep++;
                }
            }
            catch (HttpRequestException ex)
            {
                // Handle HTTP request errors
                Console.WriteLine($"An HTTP request error occurred while calling the API: {ex.Message}");

                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                }
            }
            catch (Exception ex)
            {
                // Handle API call exception if needed
                Console.WriteLine($"An error occurred while calling the API: {ex.Message}");
            }
        }
    }


}







