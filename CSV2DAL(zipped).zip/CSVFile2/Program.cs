using Microsoft.EntityFrameworkCore;
using CSVFileUpload;
using CSVFileDAL;
using CSVFileUpload.Services;
using Microsoft.OpenApi.Models;
using CSVFileUpload.Hubs;

namespace UserMgmtMVC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var myconstring = builder.Configuration.GetConnectionString("UserMgmtStr");

            ConfigureServices(builder.Services, myconstring);
            var app = builder.Build();

            Configure(app);

            app.Run();
        }

        static void ConfigureServices(IServiceCollection services, string constring = "")
        {
            services.AddControllersWithViews();

            

            // All dependency injection will be registered
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "CSV service", Version = "v1" });
            });

            services.AddScoped<ICSVService, CsvService>();

            // Dependency injection for data context
            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(constring));

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials()
                        .AllowAnyMethod()
                        .WithOrigins("http://localhost:3000")); // Add the URL of your React application
            });

            services.AddSignalR();
        }

        static void Configure(WebApplication app)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "CSV service V1");
            });

            app.UseStaticFiles();

            app.UseRouting();

            app.UseCors("CorsPolicy"); // Use the correct policy name here


            // Startup.cs

           
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<ProgressHub>("/progressHub");
                endpoints.MapControllers();
            });

            app.MapDefaultControllerRoute();
        }
    }
}
