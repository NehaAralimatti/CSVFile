﻿//using Microsoft.AspNetCore.SignalR;

//namespace CSVFileUpload.Hubs;

//public class ProgressHub : Hub
//{
//    public async Task UpdateProgress(int progress)
//    {
//        await Clients.All.SendAsync("UpdateProgress", progress);
//    }
//}
namespace CSVFileUpload.Hubs;
using Microsoft.AspNetCore.SignalR;

public class ProgressHub : Hub
{
   
    public async Task SendProgressUpdate(string progress)
    {
        await Clients.All.SendAsync("ReceiveProgress", progress);
    }

    public ProgressHub()
    {
        Console.WriteLine("ProgressHub created!");
    }

}
