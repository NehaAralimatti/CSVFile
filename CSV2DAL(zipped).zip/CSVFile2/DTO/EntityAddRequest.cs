﻿using System.ComponentModel.DataAnnotations;

namespace CSVFileUpload.DTO
{
    public class EntityAddRequest
    {
        //[Required(ErrorMessage = "The EntityName field is required.")]
        public string EntityName {  get; set; }
        //[Required(ErrorMessage = "The Description field is required.")]
        public string Description {  get; set; }
    }
}
