﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CSVFileDAL.Models;
using CsvHelper;

namespace CSVFileUpload.Services
{
    public class CsvService : ICSVService
    {
        private readonly ApplicationDbContext _dbContext;

        public CsvService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public List<T> ReadCSV<T>(Stream file)
        {
            var reader = new StreamReader(file);
            var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

            var records = csv.GetRecords<T>().ToList();

            return records;
        }

    }
}

