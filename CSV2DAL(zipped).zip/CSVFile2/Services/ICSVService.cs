﻿

using CSVFileDAL.Models;

namespace CSVFileUpload.Services;



public interface ICSVService
{
    List<T> ReadCSV<T>(Stream file);
}


